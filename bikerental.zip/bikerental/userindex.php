<?php
$id=$_REQUEST['id'];

$conn=mysqli_connect('localhost',"root","","bikerental");
$res=mysqli_query($conn,"select * from usertable where id=$id");

while($x=mysqli_fetch_array($res))
{
  $name= $x[1];              
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>userhomepage</title>
    <link href="indexcss.css" rel="stylesheet">
</head>

<body>
    <header>
        <nav>
            <div id="logo">
                <img src="icons/logo.png" alt="LOGO">
            </div>
            <div class="menu">
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="aboutus.html">ABOUT US</a>
                    <li><a href="contactus.html">CONTACT US</a></li>
                    <li><a href="gallery.html">GALLERY</a></li>
                </ul> 
            </div>
            <div id="login">
                <h1><?php echo $name; ?></h1>
        </div>

        </nav>
    </header>
    <br>
    <section id="training">
        <h1>Our Resources</h1>
        <section><img src="icons/course_1.jpg" alt="">
            <legend>Online Booking</legend>
            <P>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...".</P>
        </section>
        <section><img src="icons/course_2.jpg" alt="">
            <legend>Online Booking</legend>
            <P>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...".</P>
        </section>
        <section><img src="icons/course_3.jpg" alt="">
            <legend>Online Booking</legend>
            <P>"Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...".</P>
        </section>
    </section>

    <section id="services">
        <h1>Our Services</h1>
        <section><img src="icons/earth-globe.svg" alt="">
            <legend>Online Booking</legend>
            <P>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur,.</P>
        </section>
        <section><img src="icons/exam.svg" alt="">
            <legend>24/7 Customer Support</legend>
            <P>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur,.</P>
        </section>
        <section><img src="icons/books.svg" alt="">
            <legend>Different Cities</legend>
            <P>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur,.</P>
        </section>
        <section><img src="icons/professor.svg" alt="">
            <legend>Short Ride</legend>
            <P>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur,.</P>
        </section>
        <section><img src="icons/blackboard.svg" alt="">
            <legend>Insurance/Safety</legend>
            <P>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur,.</P>
        </section>
        <section><img src="icons/mortarboard.svg" alt="">
            <legend>Long Ride</legend>
            <P>We Provide Job Oriented Courses with placement and Real Time Project Development from Kangaroo.</P>
        </section>
    </section>

    <footer>

        <ul>
            <h3>TOUR</h3>
            <li>Web Prototyping </li>
            <li>Collaboration </li>
            <li>Integrations </li>
        </ul>
        <ul>
            <h3>LEARN</h3>
            <li> Collaboration guide</li>
            <li>Integrations guide </li>
        </ul>
        <ul>
            <h3>RESOURCES</h3>
            <li>Sign in to account </li>
            <li>Blog </li>
            <li>Customers </li>
        </ul>
        <ul>
            <h3>HELP</h3>
            <li>Learning center </li>
            <li>Q&A forums </li>
            <li>Customer support</li>
        </ul>
        <p>Copyright ©2020 All rights reserved.</p>
        <h4>FOLLOW US</h4>
        <a href="https://www.facebook.com/" target="_blank"><img src="icons/fblogo.jpg" alt="Facebook"></a>
        <a href="https://github.com/" target="_blank"><img src="icons/githublogo.png" alt="Github"></a>
        <a href="https://www.instagram.com/" target="_blank"><img src="icons/instalogo.jpg" alt="Instagram"></a>
    </footer>



</body>

</html>