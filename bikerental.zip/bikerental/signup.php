<?php
if(isset($_POST['btnreg']))
{

$name=$_POST["name"];
$dob=$_POST["dob"];
$gender=$_REQUEST["g"];
$email=$_POST["email"];
$city=$_POST["city"];
$mobile=$_POST["mobile"];
$dl=$_POST["dl"];
$pass=$_POST["pass"];

   

$id=strtotime("now");
$dor=date("d-M-Y");//date of registration.


$conn=mysqli_connect('localhost',"root","","bikerental");
$r=mysqli_query($conn,"insert into usertable(id,name,dob,gender,email,city,mobile,driving,password,dor) values('$id','$name','$dob','$gender','$email','$city','$mobile','$dl','$pass','$dor')");

    if(mysqli_affected_rows($conn)>0)
    {
        echo "Sign up Successful <br>";
    
    }
    else
    {
        echo "not Successful";
    }

}
else
{
    header('location:index.html');
}
?>