<?php
if(isset($_POST['btnlogin']))
{

$mobile=$_POST["mobile"];
$pass=$_POST["pass"];


$conn=mysqli_connect('localhost',"root","","bikerental");
$res=mysqli_query($conn,"select id from usertable where mobile=$mobile and password=$pass");


while($x=mysqli_fetch_array($res))
{
  $id= $x[0];             
}


    if(mysqli_affected_rows($conn)>0)
    {
        header("location:userindex.php?id=$id"); 

    }
    else
    {
    echo "Entered Wrong Mobile Number or Password.";
    }

}
else
{
    header('location:index.html');
}
?>